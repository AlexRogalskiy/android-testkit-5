package com.messedcode.openshoppinglist.firebase.service;

import com.google.firebase.messaging.FirebaseMessagingService;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
}
